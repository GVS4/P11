import { combineReducers } from "@reduxjs/toolkit";
import userReducer from "./userReducer";

export default combineReducers({
  user: userReducer,
});
