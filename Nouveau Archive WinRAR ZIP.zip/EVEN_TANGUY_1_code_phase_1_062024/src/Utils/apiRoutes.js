export const API_BASE_URL = "http://localhost:3001/api/v1";
export const LOGIN_URL = `${API_BASE_URL}/user/login`;
export const PROFILE_URL = `${API_BASE_URL}/user/profile`;
