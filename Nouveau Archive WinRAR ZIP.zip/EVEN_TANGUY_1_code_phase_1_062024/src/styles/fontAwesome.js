import { library } from "@fortawesome/fontawesome-svg-core";
import { fas } from "@fortawesome/free-solid-svg-icons";

// Ajouter les icônes nécessaires à la bibliothèque
library.add(fas);
